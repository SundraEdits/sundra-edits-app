# SUNDRA EDITS Android App — हिंदी गाइड

यह Android Studio प्रोजेक्ट है। इसमें ऐप का Java source code और GitHub Actions workflow शामिल है, जो GitHub पर अपलोड करने के बाद APK बनाने की कोशिश करेगा। इस ZIP में पहले से बना हुआ APK नहीं है। इस चैट के build environment में Android SDK/Gradle उपलब्ध नहीं है, इसलिए APK को यहाँ compile या फोन पर test नहीं किया गया है।

## ऐप में मौजूद सुविधाएँ
- Dashboard: clients, projects, project value, received और balance
- Client जोड़ना और client list देखना
- Project बनाना: client, project type, description, editing requirements, duration, resolution, quantity, unit price, extra charges, discount, due date
- Project status बदलना: New Request से Completed तक
- Payment entries: amount, method, transaction ID, date और note
- A4 PDF invoice: SUNDRA EDITS की दी हुई company details, client details, work description, amount, received और balance
- Caption और hashtags अलग text के रूप में सेव करना और copy करना
- Final video link सेव करना और share करना
- Project CSV export
- Local database backup और restore
- Offline local storage

## आपकी company details पहले से सेट हैं
SUNDRA EDITS | Your Vision. Our Creativity.
Mobile / WhatsApp: 9334309446
Email: sundraedits@gmail.com
Website: https://sundraedits.github.io
Address: Kanti, Muzaffarpur, Bihar - 843109
UPI: sundraedits@okicici
GST: कोई GST नंबर नहीं दिया गया है; GST अपने-आप नहीं जोड़ा जाता।

## Android फोन से APK बनाने का तरीका
इस प्रक्रिया के लिए Chrome browser और मुफ्त GitHub account चाहिए।

### Step 1 — ZIP खोलना
1. इस ZIP को फोन में डाउनलोड करें।
2. Files / File Manager ऐप खोलें और ZIP पर टैप करके Extract करें।
3. Extract होने पर `SUNDRA_EDITS_Android` नाम का folder मिलेगा।

### Step 2 — GitHub account और repository
1. Chrome में https://github.com खोलें और Sign up करके account बनाएँ या Login करें।
2. ऊपर `+` दबाएँ → `New repository` चुनें।
3. Repository name में `sundra-edits-app` लिखें।
4. `Public` चुनें (या Private रखें; दोनों में Actions चल सकते हैं)।
5. `Create repository` दबाएँ।

### Step 3 — ZIP को GitHub पर upload करें
1. अपने नए repository के मुख्य पेज पर `Add file` → `Upload files` दबाएँ।
2. फोन के Downloads folder से `SUNDRA_EDITS_Android_Project.zip` चुनें और upload करें। ZIP को extract करके अलग-अलग files upload करने की जरूरत नहीं है।
3. `Commit changes` दबाएँ।
4. अब `Add file` → `Create new file` दबाएँ। File name में बिल्कुल यह लिखें: `.github/workflows/build-apk.yml`
5. इस ZIP में मौजूद `SUNDRA_EDITS_Android/GITHUB_WORKFLOW_COPY.txt` खोलें। उसमें `name: Build SUNDRA EDITS APK` से शुरू होने वाला workflow content copy करें और GitHub की नई file में paste करें। पहली explanatory line paste न करें।
6. `Commit changes` दबाएँ।

### Step 4 — APK build चलाएँ
1. Repository में `Actions` tab खोलें।
2. `Build SUNDRA EDITS APK` workflow चुनें।
3. यदि workflow अपने-आप नहीं चला, `Run workflow` दबाएँ → फिर हरा `Run workflow` दबाएँ।
4. Build पूरा होने तक इंतज़ार करें। पहली बार कुछ मिनट लग सकते हैं।
5. अगर हरा check दिखे, workflow run खोलें। नीचे `Artifacts` में `SUNDRA-EDITS-debug-apk` दबाकर APK डाउनलोड करें।

### Step 5 — APK install करें
1. डाउनलोड की गई Artifact ZIP को Extract करें।
2. उसके अंदर `app-debug.apk` मिलेगा।
3. APK पर टैप करें। Android अनुमति माँगे तो केवल GitHub से डाउनलोड की गई अपनी build के लिए browser/files app को `Install unknown apps` की अनुमति दें।
4. Install दबाएँ और SUNDRA EDITS खोलें। काम पूरा होने पर उस अनुमति को फिर बंद कर सकते हैं।

## अगर Build fail हो जाए
1. GitHub → Actions → लाल X वाला run खोलें।
2. `Build debug APK` step खोलें।
3. सबसे नीचे की error lines का screenshot या text यहाँ भेजें। मैं error ठीक करने के लिए अगला बदलाव बताऊँगा।

## जरूरी सावधानियाँ
- यह शुरुआती functional build है; इसे अभी Android फोन पर compile/test नहीं किया गया है। इसलिए इसे production-ready या पूरी तरह bug-free न मानें।
- डेटा फोन के app storage में रहता है। App uninstall या phone reset करने से पहले Settings में Backup Database चलाकर backup सुरक्षित रखें।
- Restore Database केवल इसी ऐप का सही backup file चुनकर करें; गलत file चुनने से रिकॉर्ड खराब हो सकते हैं।
- Invoice number फिलहाल project count के आधार पर बनता है। बड़े पैमाने पर invoices भेजने से पहले invoice numbering को वास्तविक business use में test करें।
- PDF file और CSV export को Android share sheet से WhatsApp, Drive या अन्य app में भेज सकते हैं।
- Payment को app केवल तभी received मानता है जब आप खुद payment entry save करते हैं। यह बैंक/UPI से payment verify नहीं करता।
