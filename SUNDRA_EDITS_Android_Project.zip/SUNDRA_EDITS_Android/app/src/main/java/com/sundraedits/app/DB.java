package com.sundraedits.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c) { super(c, "sundra_edits.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,email TEXT,address TEXT,city TEXT,state TEXT,pin TEXT,business TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,name TEXT,type TEXT,description TEXT,requirements TEXT,duration TEXT,resolution TEXT,quantity REAL,unit TEXT,unit_price REAL,extra REAL,discount REAL,total REAL,received REAL DEFAULT 0,status TEXT,created TEXT,due TEXT,invoice_no TEXT,caption TEXT,hashtags TEXT,video_link TEXT)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,project_id INTEGER,amount REAL,method TEXT,txn TEXT,date TEXT,note TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int o,int n) {}
    public long addClient(String[] v) { ContentValues c=new ContentValues(); String[] k={"name","phone","email","address","city","state","pin","business","notes"}; for(int i=0;i<k.length;i++) c.put(k[i],v[i]); return getWritableDatabase().insert("clients",null,c); }
    public long addProject(ContentValues v) { return getWritableDatabase().insert("projects",null,v); }
    public long addPayment(long pid,double amount,String method,String txn,String date,String note) {
        SQLiteDatabase d=getWritableDatabase(); ContentValues p=new ContentValues(); p.put("project_id",pid);p.put("amount",amount);p.put("method",method);p.put("txn",txn);p.put("date",date);p.put("note",note);long id=d.insert("payments",null,p);
        Cursor c=d.rawQuery("SELECT received FROM projects WHERE id=?",new String[]{String.valueOf(pid)}); if(c.moveToFirst()){ContentValues u=new ContentValues();u.put("received",c.getDouble(0)+amount);d.update("projects",u,"id=?",new String[]{String.valueOf(pid)});} c.close(); return id;
    }
    public Cursor rows(String table) { return getReadableDatabase().rawQuery("SELECT * FROM "+table+" ORDER BY id DESC",null); }
    public Cursor project(long id) { return getReadableDatabase().rawQuery("SELECT p.*,c.name,c.phone,c.email,c.address,c.city,c.state,c.pin FROM projects p LEFT JOIN clients c ON c.id=p.client_id WHERE p.id=?",new String[]{String.valueOf(id)}); }
    public Cursor clients() { return getReadableDatabase().rawQuery("SELECT id,name,phone FROM clients ORDER BY name",null); }
    public Cursor projects() { return getReadableDatabase().rawQuery("SELECT p.id,p.name,p.total,p.received,p.status,c.name FROM projects p LEFT JOIN clients c ON c.id=p.client_id ORDER BY p.id DESC",null); }
    public int count(String table) { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);c.moveToFirst();int n=c.getInt(0);c.close();return n; }
    public double sum(String col) { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+col+"),0) FROM projects",null);c.moveToFirst();double n=c.getDouble(0);c.close();return n; }
    public void updateStatus(long id,String s) { ContentValues v=new ContentValues();v.put("status",s);getWritableDatabase().update("projects",v,"id=?",new String[]{String.valueOf(id)}); }
}
