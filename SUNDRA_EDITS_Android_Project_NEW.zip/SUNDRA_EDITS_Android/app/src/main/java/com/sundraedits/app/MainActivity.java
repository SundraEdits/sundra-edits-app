package com.sundraedits.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.content.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.database.*;
import android.database.sqlite.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(247,244,238), INK=Color.rgb(30,29,27), GOLD=Color.rgb(181,138,82), MUTED=Color.rgb(126,119,108);
    DB db; LinearLayout root, body, nav; String page="Dashboard";
    TextView syncLabel;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); splash();}
    void splash(){
        LinearLayout s=new LinearLayout(this); s.setGravity(Gravity.CENTER); s.setOrientation(1); s.setBackgroundColor(INK);
        TextView brand=new TextView(this); brand.setText("SUNDRA EDITS"); brand.setTextColor(0xfff7f4ee); brand.setTextSize(28); brand.setLetterSpacing(.18f); brand.setTypeface(null,Typeface.BOLD);
        TextView sub=new TextView(this); sub.setText("BILLING • PROJECTS • CLIENTS"); sub.setTextColor(GOLD); sub.setTextSize(10); sub.setLetterSpacing(.22f);
        s.addView(brand); s.addView(sub); setContentView(s);
        brand.setAlpha(0f); brand.animate().alpha(1f).setDuration(900).withEndAction(()->new Handler().postDelayed(this::showHome,450)).start();
    }
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
    TextView text(String v,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void showHome(){ root=column();root.setBackgroundColor(BG); setContentView(root);
        LinearLayout header=column();header.setPadding(dp(20),dp(20),dp(20),dp(14));header.setBackgroundColor(INK);
        TextView brand=text("SUNDRA EDITS",19,0xfff7f4ee,true);brand.setLetterSpacing(.12f);header.addView(brand);
        TextView tagline=text("CREATIVE WORK • CLIENT MANAGEMENT",9,GOLD,true);tagline.setPadding(0,dp(4),0,dp(9));header.addView(tagline);
        syncLabel=text("● Offline data safe  •  Drive sync not connected",10,0xffd7c5a8,false);header.addView(syncLabel);root.addView(header);
        ScrollView sc=new ScrollView(this);body=column();body.setPadding(dp(16),dp(16),dp(16),dp(18));sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(INK);String[] tabs={"Home","Clients","Projects","Payments","Invoices","Settings"};
        for(String t:tabs){TextView b=text(t,10,t.equals(page)?GOLD:0xffeee9df,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(5),dp(16),dp(5),dp(16));nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{page=t.equals("Home")?"Dashboard":t;render();});}root.addView(nav);render();
    }
    void card(String title,String value,String note){LinearLayout c=column();c.setPadding(dp(15),dp(14),dp(15),dp(14));c.setBackground(bg(Color.WHITE,16));TextView a=text(title,11,MUTED,true),b=text(value,24,INK,true),n=text(note,10,GOLD,false);c.addView(a);b.setPadding(0,dp(5),0,dp(3));c.addView(b);c.addView(n);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);body.addView(c,p);}
    void button(String label,Runnable action){TextView b=text(label,13,INK,true);b.setPadding(dp(15),dp(14),dp(15),dp(14));b.setBackground(bg(0xffeadfcf,13));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);body.addView(b,p);b.setOnClickListener(v->action.run());}
    void heading(String s){TextView t=text(s,18,INK,true);t.setPadding(0,dp(4),0,dp(12));body.addView(t);}
    void render(){body.removeAllViews();nav.removeAllViews();String[] tabs={"Home","Clients","Projects","Payments","Invoices","Settings"};for(String t:tabs){TextView b=text(t,10,(t.equals("Home")&&page.equals("Dashboard")||t.equals(page))?GOLD:0xffeee9df,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(4),dp(16),dp(4),dp(16));nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{page=t.equals("Home")?"Dashboard":t;render();});}
        if(page.equals("Dashboard")){heading("Your business at a glance");card("TOTAL CLIENTS",db.count("clients")+"","All saved customers");card("ACTIVE PROJECTS",db.countWhere("projects","status != 'Delivered'")+"","Work in progress");card("TOTAL RECEIVED","₹"+db.sum("projects","received"),"Payments recorded");card("PENDING AMOUNT","₹"+db.pending(),"Remaining project balance");button("+ ADD NEW CLIENT",()->clientDialog());button("+ CREATE PROJECT",()->projectDialog());button("RECORD PAYMENT",()->paymentDialog());button("VIEW ALL INVOICES",()->{page="Invoices";render();});}
        else if(page.equals("Clients")){heading("Clients");button("+ ADD CLIENT",()->clientDialog());list("clients");}
        else if(page.equals("Projects")){heading("Projects");button("+ CREATE PROJECT",()->projectDialog());list("projects");}
        else if(page.equals("Payments")){heading("Payments");button("+ RECORD PAYMENT",()->paymentDialog());list("payments");}
        else if(page.equals("Invoices")){heading("Invoices");button("CREATE / EXPORT INVOICE PDF",()->invoicePicker());list("invoices");}
        else settings();
    }
    void list(String table){Cursor c=db.rows(table);if(c==null)return;while(c.moveToNext()){StringBuilder s=new StringBuilder();for(int i=0;i<c.getColumnCount();i++){String k=c.getColumnName(i);if(k.equals("_id"))continue;String val=c.getString(i);if(val!=null&&!val.isEmpty()&&!k.equals("notes")&&!k.equals("description")&&!k.equals("requirements"))s.append(k.replace("_"," ")).append(": ").append(val).append("   •   ");}TextView t=text(s.toString(),12,INK,false);t.setPadding(dp(12),dp(13),dp(12),dp(13));t.setBackground(bg(Color.WHITE,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);body.addView(t,p);}c.close();}
    void settings(){heading("Settings & Backup");card("BUSINESS","SUNDRA EDITS","Kanti, Muzaffarpur, Bihar 843109");card("CONTACT","9334309446","sundraedits@gmail.com");card("WEBSITE","sundraedits.github.io","UPI: sundraedits@okicici");button("EXPORT LOCAL BACKUP",()->backup());button("RESTORE BACKUP",()->new AlertDialog.Builder(this).setMessage("Restore uses the Android file picker in the next update. Keep your old app and data until migration is verified.").setPositiveButton("OK",null).show());button("GOOGLE DRIVE SYNC",()->new AlertDialog.Builder(this).setTitle("Google Drive").setMessage("Drive API and OAuth account connection still need to be completed before automatic cloud sync can be enabled. Your data remains saved offline on this phone.").setPositiveButton("OK",null).show());}
    void fieldDialog(String title,String[] labels,java.util.function.Consumer<String[]> done){LinearLayout box=column();box.setPadding(dp(8),dp(4),dp(8),0);EditText[] es=new EditText[labels.length];for(int i=0;i<labels.length;i++){es[i]=new EditText(this);es[i].setSingleLine(true);es[i].setHint(labels[i]);box.addView(es[i]);}new AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String[] vals=new String[es.length];for(int i=0;i<es.length;i++)vals[i]=es[i].getText().toString().trim();done.accept(vals);render();}).show();}
    void clientDialog(){fieldDialog("Add Client",new String[]{"Client name","Phone / WhatsApp","Email","Address","Business / Shop"},v->db.addClient(v));}
    void projectDialog(){fieldDialog("Create Project",new String[]{"Client ID","Project name","Type","Description","Total amount ₹","Due date"},v->db.addProject(v));}
    void paymentDialog(){fieldDialog("Record Payment",new String[]{"Project ID","Amount ₹","Method","Transaction ID / Note"},v->db.addPayment(v));}
    void invoicePicker(){fieldDialog("Invoice details",new String[]{"Project ID"},v->{try{makeInvoice(Integer.parseInt(v[0]));}catch(Exception e){toast("Valid Project ID डालें");}});}
    void makeInvoice(int id){Cursor c=db.project(id);if(c==null||!c.moveToFirst()){toast("Project नहीं मिला");return;}String client=c.getString(c.getColumnIndexOrThrow("client_name")),name=c.getString(c.getColumnIndexOrThrow("name"));double total=c.getDouble(c.getColumnIndexOrThrow("total")),paid=c.getDouble(c.getColumnIndexOrThrow("received"));c.close();
        PdfDocument pdf=new PdfDocument();PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();PdfDocument.Page p=pdf.startPage(pi);android.graphics.Canvas cv=p.getCanvas();android.graphics.Paint paint=new android.graphics.Paint(3);paint.setColor(INK);paint.setTextSize(24);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));cv.drawText("SUNDRA EDITS",48,70,paint);paint.setTextSize(11);paint.setTypeface(Typeface.DEFAULT);cv.drawText("Kanti, Muzaffarpur, Bihar 843109",48,92,paint);cv.drawText("Phone: 9334309446  |  sundraedits@gmail.com",48,110,paint);paint.setColor(GOLD);cv.drawRect(48,130,547,133,paint);paint.setColor(INK);paint.setTextSize(20);cv.drawText("INVOICE",48,175,paint);paint.setTextSize(13);cv.drawText("Client: "+client,48,220,paint);cv.drawText("Project: "+name,48,248,paint);cv.drawText("Total: INR "+total,48,310,paint);cv.drawText("Received: INR "+paid,48,338,paint);cv.drawText("Balance: INR "+(total-paid),48,366,paint);cv.drawText("Thank you for choosing SUNDRA EDITS.",48,450,paint);pdf.finishPage(p);
        try{File dir=new File(getExternalFilesDir(null),"Invoices");dir.mkdirs();File f=new File(dir,"Sundra_Invoice_"+id+".pdf");pdf.writeTo(new FileOutputStream(f));toast("PDF saved: "+f.getName());}catch(Exception e){toast("PDF export failed");}pdf.close();}
    void backup(){try{File f=new File(getExternalFilesDir(null),"SUNDRA_EDITS_Backup.db");db.copyTo(f);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_STREAM,android.net.Uri.fromFile(f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Save backup"));}catch(Exception e){toast("Backup failed");}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"sundra_edits.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,email TEXT,address TEXT,business TEXT)");
            d.execSQL("CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,name TEXT,type TEXT,description TEXT,total REAL DEFAULT 0,received REAL DEFAULT 0,status TEXT DEFAULT 'New',due TEXT,created TEXT,invoice_no TEXT)");
            d.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,project_id INTEGER,amount REAL,method TEXT,txn TEXT,date TEXT,note TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        int count(String t){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t,null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
        int countWhere(String t,String w){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t+" WHERE "+w,null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
        double sum(String t,String col){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+col+"),0) FROM "+t,null);c.moveToFirst();double x=c.getDouble(0);c.close();return x;}
        double pending(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total-received),0) FROM projects",null);c.moveToFirst();double x=c.getDouble(0);c.close();return x;}
        Cursor rows(String t){String q=t.equals("invoices")?"SELECT id,invoice_no,name,total,received,status FROM projects": "SELECT * FROM "+t;return getReadableDatabase().rawQuery(q,null);}
        void addClient(String[] v){ContentValues x=new ContentValues();x.put("name",v[0]);x.put("phone",v[1]);x.put("email",v[2]);x.put("address",v[3]);x.put("business",v[4]);getWritableDatabase().insert("clients",null,x);}
        void addProject(String[] v){ContentValues x=new ContentValues();try{x.put("client_id",Long.parseLong(v[0]));}catch(Exception e){x.put("client_id",0);}x.put("name",v[1]);x.put("type",v[2]);x.put("description",v[3]);try{x.put("total",Double.parseDouble(v[4]));}catch(Exception e){x.put("total",0);}x.put("due",v[5]);x.put("created",new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));x.put("status","New");x.put("invoice_no","SE-"+System.currentTimeMillis());getWritableDatabase().insert("projects",null,x);}
        void addPayment(String[] v){ContentValues x=new ContentValues();int id=0;double amount=0;try{id=Integer.parseInt(v[0]);amount=Double.parseDouble(v[1]);}catch(Exception e){}x.put("project_id",id);x.put("amount",amount);x.put("method",v[2]);x.put("txn",v[3]);x.put("date",new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));getWritableDatabase().insert("payments",null,x);getWritableDatabase().execSQL("UPDATE projects SET received=received+? WHERE id=?",new Object[]{amount,id});}
        Cursor project(int id){return getReadableDatabase().rawQuery("SELECT p.*,COALESCE(c.name,'') client_name FROM projects p LEFT JOIN clients c ON c.id=p.client_id WHERE p.id=?",new String[]{""+id});}
        void copyTo(File f)throws Exception{File src=new File(getReadableDatabase().getPath());try(InputStream in=new FileInputStream(src);OutputStream out=new FileOutputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}}
    }
}
