# SUNDRA EDITS Android Project
Package: com.sundraedits.app

Open this folder in Android Studio, or upload the ZIP to the existing GitHub repository and run the Actions build workflow.
This starter rebuild includes a premium black/cream/champagne dashboard, animated text-only opening screen, offline SQLite clients/projects/payments, invoice PDF export with SUNDRA EDITS text branding, and local backup export.

IMPORTANT:
- The existing database is named `sundra_edits.db`, schema version 1. Back up the old app data before installing this rebuild.
- This build does NOT yet include Google Drive OAuth/automatic sync. The Settings screen clearly marks Drive as not connected. Do not treat local backup as cloud sync.
- The invoice remains text-branded and does not use the launcher icon artwork.
- Before release, test migration and signing continuity with the original app.
